/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cpubenchmark;

import java.lang.management.*;
import java.util.List;
import java.util.Random;

public class CpuBenchmark {
private static int theSum = 0;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
       boolean e,f,g,h;
        Random rand = new Random();
        float a,b;
        double c,d;
        
       
        CompilationMXBean bean = ManagementFactory.getCompilationMXBean();
  if (bean == null)
    {
      System.out.println("The compilation bean is not supported by this VM.");
      System.exit(-1);
    }
  System.out.println("Bean: " + bean);
  System.out.println("JIT compiler name: " + bean.getName());
  boolean timeMonitoring = bean.isCompilationTimeMonitoringSupported();
  System.out.println("Compilation time monitoring supported: " + timeMonitoring);
  if (timeMonitoring)
    {
      System.out.println("Compilation time: "
                         + bean.getTotalCompilationTime() + "ms");
    }
   //warmup... make sure all JIT comliling is done before the actual benchmarking starts
         
   long floataddbenchmark=0,floatsubbenchmark=0,doubleaddbenchmark=0,
           doublesubbenchmark=0,andbenchmark=0,xorbenchmark=0;
     for(int i=0; i<9; i++) 
     {  e=rand.nextBoolean();
        f=rand.nextBoolean();
        g=rand.nextBoolean();
        h=rand.nextBoolean();
        a=rand.nextFloat()*1000;
        b=rand.nextFloat()*1000;
        c=rand.nextDouble()*1000;
        d=rand.nextDouble()*1000;
  floataddbenchmark+=testfloatadd(a,b);
  Thread.sleep(5000);
  floatsubbenchmark+=testfloatsub(a,b);
  Thread.sleep(5000);
  doubleaddbenchmark+=testdoubleadd(c,d);
  Thread.sleep(5000);
  doublesubbenchmark+=testdoublesub(c,d);
   Thread.sleep(5000);
  andbenchmark+=testand(e,f);
  Thread.sleep(5000);
  xorbenchmark+=testxor(g,h);
     }
  System.out.println("Test completed... printing results");
  System.out.println("floataddbenchmark : " + floataddbenchmark/10);
  System.out.println("doubleaddbenchmark : " + doubleaddbenchmark/10);
  System.out.println("floatsubbenchmark : " + floatsubbenchmark/10);
  System.out.println("doublesubbenchmark : " + doublesubbenchmark/10);
   System.out.println("andbenchmark : " + andbenchmark/10);
  System.out.println("xorbenchmark : " + xorbenchmark/10);
  
    }
    
    private static long testfloatadd (float a, float b) {
         CompilationMXBean bean = ManagementFactory.getCompilationMXBean();
        float result=0;
        long start = System.nanoTime();        
        result=a+b; 
        long end = System.nanoTime(); 
         // System.out.println("bean.getTotalCompilationTime="+bean.getTotalCompilationTime());
        return end-start;
    }
    private static long testfloatsub (float a, float b) {
         CompilationMXBean bean = ManagementFactory.getCompilationMXBean();
        float result=0;
        long start = System.nanoTime();        
        result=a-b; 
        long end = System.nanoTime(); 
         // System.out.println("bean.getTotalCompilationTime="+bean.getTotalCompilationTime());
        return end-start;
    }

   private static long testdoubleadd (double a, double b) {
         CompilationMXBean bean = ManagementFactory.getCompilationMXBean();
        double result=0;
        long start = System.nanoTime();        
        result=a+b; 
        long end = System.nanoTime(); 
         // System.out.println("bean.getTotalCompilationTime="+bean.getTotalCompilationTime());
        return end-start;
    }
   private static long testdoublesub (double a, double b) {
         CompilationMXBean bean = ManagementFactory.getCompilationMXBean();
        double result=0;
        long start = System.nanoTime();        
        result=a-b; 
        long end = System.nanoTime(); 
         // System.out.println("bean.getTotalCompilationTime="+bean.getTotalCompilationTime());
        return end-start;
    }
    private static long testand (boolean a, boolean b) {
         CompilationMXBean bean = ManagementFactory.getCompilationMXBean();
        boolean result;
        long start = System.nanoTime();        
        result=a&b; 
        long end = System.nanoTime(); 
         // System.out.println("bean.getTotalCompilationTime="+bean.getTotalCompilationTime());
        return end-start;
    }
     private static long testxor (boolean a, boolean b) {
         CompilationMXBean bean = ManagementFactory.getCompilationMXBean();
        boolean result;
        long start = System.nanoTime();        
        result=a^b; 
        long end = System.nanoTime(); 
         // System.out.println("bean.getTotalCompilationTime="+bean.getTotalCompilationTime());
        return end-start;
    }
    // invocations to this method simply exist to fool the VM into thinking that we are doing something useful in the loop
    private static void setSum(int sum) {
        theSum = sum;       
    }
    
}
