#include <stdio.h>

int fact(int); 

int main() {
int offset;
offset=atoi(strstr("#123","#")+1);
   printf("offset is %d \n", offset);
}

int fact( int n) {
  int temp;
  if (n==0) return 1;
  else {
     temp = n*fact(n-1);
     return temp;
  }
}
